package com.bancodedadoscinema.bancodedados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancodedadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
