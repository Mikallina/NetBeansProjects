/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cinema.controller;

import com.mycompany.cinema.model.Analise;
import com.mycompany.cinema.model.Filme;
import com.mycompany.cinema.repository.AnaliseRepository;
import com.mycompany.cinema.repository.FilmeRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author mi_bo
 */
@Controller
@RequestMapping("/analises")
public class AnaliseController {

    private final AnaliseRepository analiseRepository;
    private final FilmeRepository filmeRepository;

    public AnaliseController(AnaliseRepository analiseRepository, FilmeRepository filmeRepository) {
        this.analiseRepository = analiseRepository;
        this.filmeRepository = filmeRepository;
    }

    @GetMapping("/adicionar")
    public String adicionarAnalise(Long filmeId, Model model) {
        Filme filme = filmeRepository.findById(filmeId).orElseThrow();
        model.addAttribute("filme", filme);
        model.addAttribute("analise", new Analise());

        model.addAttribute("analises", analiseRepository.findAllByFilmeId(filmeId));

        return "analises/form";
    }

    @PostMapping("/salvar")
    public String salvarAnalise(@ModelAttribute Analise analise, Long filmeId) {
        Filme filme = filmeRepository.findById(filmeId).orElseThrow();

        analise.setFilme(filme);

        analiseRepository.save(analise);

        return "redirect:/analises/adicionar?filmeId=" + filmeId;
    }
}
