/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.cinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @author mi_bo
 */
@SpringBootApplication
public class Cinema {

    public static void main(String[] args) {
        SpringApplication.run(Cinema.class, args);
    }
}
