/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cinema.repository;

import com.mycompany.cinema.model.Filme;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/**
 *
 * @author mi_bo
 */
@Repository
public class FilmeRepository {

    private List<Filme> filmes = new ArrayList<>();
    private static Long counter = 1L;

    public List<Filme> findAll() {
        return filmes;
    }

    public Optional<Filme> findById(Long id) {
        return filmes.stream().filter(f -> f.getId().equals(id)).findFirst();
    }

    public void save(Filme filme) {
        if (filme.getId() == null) {
            filme.setId(counter++);
        }
        filmes.add(filme);
    }

    public void delete(Long id) {
        filmes.removeIf(f -> f.getId().equals(id));
    }
}
