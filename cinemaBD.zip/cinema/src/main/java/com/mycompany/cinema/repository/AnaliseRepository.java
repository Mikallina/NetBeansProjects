/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cinema.repository;

import com.mycompany.cinema.model.Analise;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

/**
 *
 * @author mi_bo
 */
@Repository
public class AnaliseRepository {

    private List<Analise> analises = new ArrayList<>();
    private static Long counter = 1L;

    public List<Analise> findAllByFilmeId(Long filmeId) {
        List<Analise> result = new ArrayList<>();
        for (Analise a : analises) {
            if (a.getFilme().getId().equals(filmeId)) {
                result.add(a);
            }
        }
        return result;
    }

    public void save(Analise analise) {
        if (analise.getId() == null) {
            analise.setId(counter++);
        }
        analises.add(analise);
    }
}
